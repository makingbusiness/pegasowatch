<?php
class Inicio extends CI_Controller{
	
	public function __construct()
	{
		parent::__construct();
		$this->load->library('session');
		$this->load->model('productos_model');

		if (!$this->session->has_userdata('total_items_carro'))
		{
			$this->session->set_userdata('total_items_carro', '0');
		}
		
		if (!$this->session->has_userdata('idioma'))
		{
			$this->session->set_userdata('idioma', '1');
		}
		
		if (!$this->session->has_userdata('IDTipoUsuario'))
		{
			$this->session->set_userdata('IDTipoUsuario', '1');		
		}
		
		$this->session->set_userdata('value-lower','1000');
		$this->session->set_userdata('value-upper','2000000');
	}
	
	public function index()
	{
		$data['productos'] = $this->productos_model->lista_productos_promocion();

		$this->session->set_userdata('pais_base', true);
				
		$this->load->view('templates/header');
		$this->load->view("home",$data);
		$this->load->view('templates/footer');
	}

	public function pais($pais)
	{
		$data['productos'] = $this->productos_model->lista_productos_promocion();
		$this->session->set_userdata('pais_base', $pais == 1 ? true : false);	

		$this->load->view('templates/header');
		$this->load->view("home",$data);
		$this->load->view('templates/footer');
	}
}