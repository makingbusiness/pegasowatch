<?php

class Productos_model extends CI_Model{
    
    public function __construct()
	{
        parent::__construct();
        $this->load->library('session');        
    }

    public function eliminar_productos($statur, $carga = 'N'){
        $data = array('Activo' => 'N');

        //$this->db->where('ST',$statur ? 'S' : 'N');
        $tabla = $carga == 'S' ? 'productos2' : 'productos';
        $this->db->update($tabla,$data);
    }

    public function existeProducto($producto,$carga = 'N'){

        $tabla = $carga == 'S' ? 'productos2' : 'productos';
        $this->db->from($tabla);
        $this->db->where('CodProd',$producto);

        return $this->db->count_all_results();
    }

    public function inserta_producto($producto,$statur,$carga = 'N'){

        $tabla = $carga == 'S' ? 'productos2' : 'productos';

        $data = array(
            'CodProd'         => $producto->codprod,
            'CodInst'         => $producto->codinst,
            'Impuesto'        => $producto->impuesto,
            'Marca'           => $producto->marca,
            'CodigoAux'       => $producto->codigoaux,
            'RefBase'         => $producto->refBase,
            'Precio1'         => $producto->precio1,
            'Precio2'         => $producto->precio2,
            'Precio3'         => $producto->precio3,
            'Precio4'         => $producto->precio4,
            'PrecioInternet'  => $producto->precioInternet,
            'PrecioWA'        => $producto->precioWA,
            'Activo'          => 'S',
            'ST'              => $statur ? 'S' : 'N',
            'EsNuevo'         => $producto->EsNuevo,
            'ImgPrincipal'    => $producto->imgPrincipal,
            'ImgAdicionales'  => $producto->imgAdicional,
            'ImgTexturas'     => $producto->imgTextura,
            'ImgStatur'       => $producto->imgStatur
        );

        $this->db->insert($tabla,$data);
     }

     public function actualizar_productos($producto,$statur,$carga = 'N'){

         $tabla = $carga == 'S' ? 'productos2' : 'productos';
         $data = array(
            'CodInst'         => $producto->codinst,
            'Impuesto'        => $producto->impuesto,
            'Marca'           => $producto->marca,
            'CodigoAux'       => $producto->codigoaux,
            'RefBase'         => $producto->refBase,
            'Precio1'         => $producto->precio1,
            'Precio2'         => $producto->precio2,
            'Precio3'         => $producto->precio3,
            'Precio4'         => $producto->precio4,
            'PrecioInternet'  => $producto->precioInternet,
            'PrecioWA'        => $producto->precioWA,            
            'Activo'          => 'S',
            'ST'              => $statur ? 'S' : 'N',
            'EsNuevo'         => $producto->EsNuevo,
            'ImgPrincipal'    => $producto->imgPrincipal,
            'ImgAdicionales'  => $producto->imgAdicional,
            'ImgTexturas'     => $producto->imgTextura,
            'ImgStatur'       => $producto->imgStatur
         );

         $this->db->where('CodProd',$producto->codprod);
         $this->db->update($tabla,$data);
     }

     public function eliminar_auxiliares($carga = 'N'){
        $data = array('Activo' => 'N');
        
        $this->db->update($carga == 'S' ? 'auxiliares_producto2' : 'auxiliares_producto',$data);
    }

    public function existeAuxiliar($producto,$carga){
        $this->db->from($carga == 'S' ? 'auxiliares_producto2' : 'auxiliares_producto');
        $this->db->where('CodigoAux',$producto);

        return $this->db->count_all_results();
    }

    public function inserta_auxiliar($producto,$carga = 'N'){

        $data = array(
            'CodigoAux'      => $producto->codigoaux,
            'ListaProductos' => $producto->listaProductos,
            'RefBase'        => $producto->refBase,
            'Activo'         => 'S'
        );

        $this->db->insert($carga == 'S' ? 'auxiliares_producto2' : 'auxiliares_producto',$data);
     }

     public function actualizar_auxiliar($producto,$carga = 'N'){
         $data = array(
            'ListaProductos' => $producto->listaProductos,
            'RefBase'        => $producto->refBase,
            'Activo'         => 'S'
         );

         $this->db->where('CodigoAux',$producto->codigoaux);
         $this->db->update($carga == 'S' ? 'auxiliares_producto2' : 'auxiliares_producto',$data);
     }

    public function eliminar_productos_idioma($carga = 'N'){
        $data = array('Activo' => 'N');

        $this->db->update($carga == 'S' ? 'productos_idioma2' : 'productos_idioma',$data);
    }

    public function inserta_producto_idioma($producto, $carga = 'N'){

        $data = array(
            'CodProd'      => $producto->codprod,
            'Descrip'      => $producto->descrip,
            'Descrip2'     => $producto->descrip2,
            'Descrip3'     => $producto->descrip3,
            'IDIdioma'     => $producto->IDIdioma,
            'DescAmpliada' => $producto->descAmpliada,
            'Activo'       => 'S'
        );

        $this->db->insert($carga == 'S' ? 'productos_idioma2' :'productos_idioma',$data);
     }

     public function actualizar_producto_idioma($producto, $carga = 'N'){
        $data = array(
            'Descrip'      => $producto->descrip,
            'Descrip2'     => $producto->descrip2,
            'Descrip3'     => $producto->descrip3,
            'DescAmpliada' => $producto->descAmpliada,
            'Activo'       => 'S'
        );

        $this->db->where('CodProd', $producto->codprod);
        $this->db->where('IDIdioma',$producto->IDIdioma);
        $this->db->update($carga == 'S' ? 'productos_idioma2' : 'productos_idioma',$data);
     }

     public function existe_producto_idioma($producto,$carga = 'N'){
         $this->db->from($carga == 'S' ? 'productos_idioma2' : 'productos_idioma');
         $this->db->where('CodProd',$producto->codprod);
         $this->db->where('IDIdioma',$producto->IDIdioma);

         return $this->db->count_all_results();
     }

     public function eliminar_precios_producto(){
        $data = array('Activo' => 'N');

        $this->db->update('precios_producto',$data);
    }

    public function inserta_precio_producto($producto){

        $data = array(
            'CodProd'       => $producto->codprod,
            'IDTipoUsuario' => $producto->tipo,
            'Precio'        => $producto->precio,
            'Activo'        => 'S'
        );

        $this->db->insert('precios_producto',$data);
     }

     public function actualizar_precio_producto($producto){
        $data = array(
            'Precio' => $producto->precio,
            'Activo' => 'S'
        );

        $this->db->where('CodProd', $producto->codprod);
        $this->db->where('IDTipoUsuario',$producto->tipo);
        $this->db->update('precios_producto',$data);
     }

     public function existe_precio_producto($producto){
         $this->db->from('precios_producto');
         $this->db->where('CodProd',$producto->codprod);
         $this->db->where('IDTipoUsuario',$producto->tipo);

         return $this->db->count_all_results();
     }

     public function eliminar_pulsos($carga = 'N'){
        $data = array('Activo' => 'N');

        $this->db->update($carga == 'S' ? 'referencias_manilla2' : 'referencias_manilla',$data);
    }

    public function inserta_pulso($producto,$carga = 'N'){

        $data = array(
            'CodProd'       => $producto->codprod,
            'Descrip'       => $producto->descrip,
            'ListaCalibres' => $producto->calibre,
            'ListaColores'  => $producto->color,
            'ListaPartes'   => $producto->partes,
            'CodInst'       => $producto->codinst,
            'Impuesto'      => $producto->impuesto,
            'Activo'        => 'S'
        );

        $this->db->insert($carga == 'S' ? 'referencias_manilla2' : 'referencias_manilla',$data);
     }

     public function actualizar_pulso($producto,$carga = 'N'){
        $data = array(
            'Descrip'       => $producto->descrip,
            'ListaCalibres' => $producto->calibre,
            'ListaColores'  => $producto->color,
            'ListaPartes'   => $producto->partes,
            'CodInst'       => $producto->codinst,
            'Impuesto'      => $producto->impuesto,
            'Activo'        => 'S'
        );

        $this->db->where('CodProd', $producto->codprod);
        $this->db->update($carga == 'S' ? 'referencias_manilla2' : 'referencias_manilla',$data);
     }

     public function existe_pulso($producto,$carga = 'N'){
         $this->db->from($carga == 'S' ? 'referencias_manilla2' : 'referencias_manilla');
         $this->db->where('CodProd',$producto->codprod);

         return $this->db->count_all_results();
     }
}
