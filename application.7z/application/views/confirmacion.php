	<!-- Title Page -->
	<section class="bg-title-page p-t-40 p-b-50 flex-col-c-m" style="background-color: black; min-height: 150px;">
		<h2 class="l-text3 t-center">
			<?php echo $resultado_epayco; ?>
		</h2>
		<p class="s-text1"></p>
	</section>

	<!-- content page -->
	<section class="bgwhite p-t-66 p-b-60">
		<div class="container">
			<div class="row justify-content-md-center">
				<div class="col-md-6 p-b-30 text-center">
					<h2 class="l-text3 t-center">
						Gracias por su compra.<br>Para ciudades principales, el pedido se entrega en 2 d&iacute;as h&aacute;biles.<br>
						Para ciudades intermedias, el pedido se entrega m&aacute;ximo en 5 d&iacute;as h&aacute;biles
					</h2>
				</div>
			</div>
		</div>
	</section>
